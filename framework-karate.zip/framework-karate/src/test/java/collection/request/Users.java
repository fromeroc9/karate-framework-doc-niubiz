package collection.request;

import collection.helpers.Hook;
import collection.params.UsersParams;
import org.json.simple.JSONObject;

public class Users extends Hook {

    private static UsersParams up;

    public static JSONObject data(String cp) throws Throwable {
        int index = Integer.parseInt(cp) - 1;

        String NAME = getData().get(index).get(up.COL_NAME);
        String USERNAME = getData().get(index).get(up.COL_USERNAME);
        String EMAIL = getData().get(index).get(up.COL_EMAIL);
        String STREET = getData().get(index).get(up.COL_STREET);
        String CITY = getData().get(index).get(up.COL_CITY);
        String ZIPCODE = getData().get(index).get(up.COL_ZIPCODE);
        String PHONE= getData().get(index).get(up.COL_PHONE);

        JSONObject JSAddress = new JSONObject();
        JSAddress.put("street", STREET);
        JSAddress.put("city", CITY);
        JSAddress.put("zipcode", ZIPCODE);

        JSONObject data1 = new JSONObject();
        data1.put("name", NAME);
        data1.put("username", USERNAME);
        data1.put("email", EMAIL);
        data1.put("address", JSAddress);
        data1.put("phone", PHONE);

        return data1;
    }

    public static JSONObject dataJSON(String cp) throws Throwable {
        int index = Integer.parseInt(cp) - 1;

        String NAME = getDataJSON(index, up.COL_NAME);
        String USERNAME = getDataJSON(index, up.COL_USERNAME);
        String EMAIL = getDataJSON(index, up.COL_EMAIL);
        String STREET = getDataJSON(index, up.COL_STREET);
        String CITY = getDataJSON(index, up.COL_CITY);
        String ZIPCODE = getDataJSON(index, up.COL_ZIPCODE);
        String PHONE= getDataJSON(index, up.COL_PHONE);

        JSONObject JSAddress = new JSONObject();
        JSAddress.put("street", STREET);
        JSAddress.put("city", CITY);
        JSAddress.put("zipcode", ZIPCODE);

        JSONObject data1 = new JSONObject();
        data1.put("name", NAME);
        data1.put("username", USERNAME);
        data1.put("email", EMAIL);
        data1.put("address", JSAddress);
        data1.put("phone", PHONE);

        return data1;
    }

}
