package collection.runner;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import cucumber.api.CucumberOptions;
import org.junit.jupiter.api.Test;

import static collection.utility.CucumberReport.generateReport;

public class TestRunner {

    @Test
    public void testParallel() {
        Results results = Runner.path(
                "classpath:resources/features/Users.feature"
            ).outputCucumberJson(true).outputHtmlReport(true)
            .parallel(1);
        generateReport(results.getReportDir());
    }


}
