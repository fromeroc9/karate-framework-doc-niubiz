package collection.utility;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;;

public class JsonReader {

    public static String data(String rutaRelativa, int index, String param) throws IOException {
        JSONParser jsonParser = new JSONParser();
        try {
            String ruta = FileHelper.getProjectFolder() + "/src/test/java/resources/fixtures/" + rutaRelativa;
            FileReader reader = new FileReader(ruta);

            //Read JSON file
            Object parseObject = jsonParser.parse(reader);
            JSONArray  data = (JSONArray) parseObject;

            JSONObject current = (JSONObject) data.get(index);
            String response = (String) current.get(param);

            return response;
        } catch (FileNotFoundException e) {
            System.out.println("[ERROR] " + e.getMessage());
            return null;
        } catch (IOException e) {
            System.out.println("[ERROR] " + e.getMessage());
            return null;
        } catch (ParseException e) {
            System.out.println("[ERROR] " + e.getMessage());
            return null;
        }
    }

}
