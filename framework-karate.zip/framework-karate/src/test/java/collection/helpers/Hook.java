package collection.helpers;

import collection.utility.ExcelReader;
import collection.utility.JsonReader;

import java.util.HashMap;
import java.util.List;

public class Hook {

    private static String FILE1 = "data.xlsx";
    private static String SHEET1 = "Casos Prueba";

    private static String JSON1 = "data.json";

    protected static List<HashMap<String, String>> getData() throws Throwable {
        return ExcelReader.data(FILE1, SHEET1);
    }

    protected static void setData(int row, int cell, String result) throws Throwable {
        ExcelReader.writeCellValue(FILE1, SHEET1, row, cell, result);
    }

    protected static String getDataJSON(int index, String param) throws Throwable {
        return JsonReader.data(JSON1, index, param);
    }

}
