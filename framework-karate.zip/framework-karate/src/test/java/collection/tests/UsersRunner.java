package collection.tests;

import com.intuit.karate.junit5.Karate;

public class UsersRunner {

    @Karate.Test
    Karate UsersRunner(){
        return Karate.run("classpath:resources/features/Users.feature").relativeTo(getClass());
    }


}
