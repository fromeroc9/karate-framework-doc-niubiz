package collection.params;

public class UsersParams {

    public static final String COL_NAME = "Name";
    public static final String COL_USERNAME = "Username";
    public static final String COL_EMAIL = "Email";
    public static final String COL_STREET = "Street";
    public static final String COL_CITY = "City";
    public static final String COL_ZIPCODE = "Zipcode";
    public static final String COL_PHONE = "Phone";

}
